import React from 'react'

const Lab6 = () => {
  return (
    <div>
      Lab 6
    </div>
  )
}

export default Lab6
