import React from 'react'

const Lab3 = () => {
  return (
    <div>
      Welcome to Lab experiment - Secrion7
    </div>
  )
}

export default Lab3
