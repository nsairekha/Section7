import React from 'react'

const Lab4 = () => {
  return (
    <div>
      Lab 4
    </div>
  )
}

export default Lab4
